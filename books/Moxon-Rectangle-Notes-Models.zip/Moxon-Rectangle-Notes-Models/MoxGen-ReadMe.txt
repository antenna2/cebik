
MoxGen will show you the dimensions and (optionally) generate an antenna model file for a 50 ohm Moxon Rectangle antenna, given the design frequency and wire size.  The program is based on an algorithm developed by L. B. Cebik, W4RNL.  For a complete discussion of Moxon Rectangle antennas see www.cebik.com/moxpage.html.

Program usage notes:
1. Results are automatically recalculated when you:
   a) click the Calculate button (or press Alt-C)
   b) press the Enter key
   c) change the output units
   d) click the Print button (or press Alt-P) 
   e) click the Generate Model button (or press Alt-G)

2. You can enter a wire size in AWG units by typing "#" followed by the wire size, no matter what the current wire size units setting is.  If the setting is already "AWG" you can just enter the gauge number with or without the leading "#" sign.

3. Printing is done with a white background.  Buttons on the right side of the window are intentionally not printed.  You'll be asked to confirm a print request.

4. International users:  You should enter the frequency and wire size values using a comma as a decimal symbol if that is the standard for your region.  The NEC file generated (if any) will be formatted using a period, as is required by the NEC calculating engines.


73
Dan Maguire  AC6LA
www.qsl.net/ac6la/
email:  ac6la@arrl.net