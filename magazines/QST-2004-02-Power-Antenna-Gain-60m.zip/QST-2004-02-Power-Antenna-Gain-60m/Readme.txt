Readme.txt for www.arrl.org/files/QST-binaries/Cebik0204.zip

Cebik0204.zip contains files pertaining to "Power and Antenna Gain on 60 Meters," by L. B. Cebik, W4RNL (QST, Feb 2004, pp 36-42). At the time this was posted, the author's e-mail was cebik@cebik.com.

For more information about how to use the files, browse to the author's "Flipping Among NEC Programs" (https://www.antenna2.net/cebik/content/amod/amod52.html) and his general Web page, "Antenna Modeling" (https://www.antenna2.net/cebik/content/amod/modeling.html). The earlier one tells what software to use.


73, Bob, KU7G
5:41 PM 01/05/2004

Robert J. Schetgen, KU7G/1				Senior Assistant Technical Editor			
American Radio Relay League, 225 Main St, Newington, CT 06111-1494
ph: 860-594-0277 (direct)					fax: 860-594-0259	
e-mail: rschetgen@arrl.org  

QST Team  *  Hints & Kinks Editor   *  QEX Managing Editor							

Have you seen the new QEX? Wow! Check it out at http://www.arrl.org/qex/.

